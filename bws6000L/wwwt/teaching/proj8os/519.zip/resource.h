//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by proc.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_PROCTYPE                    129
#define IDD_DIALOG1                     130
#define IDD_DIALOG2                     131
#define IDB_BITMAP1                     132
#define IDB_HEADER                      132
#define IDB_CHECKBOXSTATUS              133
#define IDB_TREE_PICTURES               134
#define IDC_EDIT1                       1000
#define IDC_SPIN1                       1001
#define IDC_EDIT2                       1001
#define ID_KILL                         32771
#define ID_DUMP                         32774
#define ID_PROCESS_PRIORITY             32775
#define ID_OPEN                         32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
